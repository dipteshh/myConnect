import React, { Component } from "react";
import { Text, TextInput, TouchableOpacity } from "react-native";

import { Container, Spinner, TextH3 } from "../UI";

import * as Permissions from "expo-permissions";

import { BarCodeScanner } from "expo-barcode-scanner";

import { window } from "../constants/Layout";

import Inputs from "../components/Inputs";

class HomeScreen extends Component {
  static navigationOptions = {
    header: null,
  };
  // Component State
  state = {
    hasCameraPermission: null, // if app has permissions to acess camera
    isScanned: false, // scanned
    scannedData: "",
    dataName: "",
  };
  async componentDidMount() {
    // ask for camera permission
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    console.log(status);
    this.setState({ hasCameraPermission: status === "granted" ? true : false });
  }

  handleBarCodeScanned = ({ type, data }) => {
    // Do something here
    // this.props.navigation.navigate("Decode", {
    //   data: data,
    // });
    this.setState({ scannedData: data });
  };

  handleData = (text) => {
    this.setState({ dataName: text });
  };

  render() {
    const { hasCameraPermission, isScanned } = this.state;
    if (hasCameraPermission === null) {
      // requesting permission
      return <Spinner />;
    }
    if (hasCameraPermission === false) {
      //permission denied
      return (
        <Container>
          <TextH3>Please grant Camera permission</TextH3>
        </Container>
      );
    }
    if (
      hasCameraPermission === true &&
      !isScanned &&
      this.props.navigation.isFocused()
    ) {
      // we have permission and this screen is under focus
      return (
        <Container
          style={{
            flex: 1,
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextH3>Scan code inside window</TextH3>
          <BarCodeScanner
            onBarCodeScanned={isScanned ? undefined : this.handleBarCodeScanned}
            style={{
              height: window.height / 2,
              width: window.height,
            }}
          ></BarCodeScanner>

          <TextInput
            style={{
              margin: 15,
              width: window.width / 1.5,
              height: 40,
              borderColor: "#7a42f4",
              borderWidth: 1,
              borderRadius: 10,
              textAlign: "center",
            }}
            underlineColorAndroid="transparent"
            placeholder="No Data yet"
            placeholderTextColor="#9a73ef"
            autoCapitalize="none"
            value={this.state.scannedData}
            multiline={true}
          />
          <TextInput
            style={{
              margin: 15,
              width: window.width / 1.5,
              height: 40,
              borderColor: "#7a42f4",
              borderWidth: 1,
              borderRadius: 10,
              textAlign: "center",
            }}
            underlineColorAndroid="transparent"
            placeholder="Enter Name"
            placeholderTextColor="#9a73ef"
            autoCapitalize="none"
            onChangeText={this.handleData}
          />

          <TouchableOpacity
            style={{
              backgroundColor: "#7a42f4",
              padding: 10,
              margin: 15,
              height: 40,
            }}
          >
            <Text
              style={{
                color: "white",
              }}
            >
              {" "}
              Save{" "}
            </Text>
          </TouchableOpacity>

          {/* <Inputs>
            {this.state.scannedData !== "" ? this.state.scannedData : "No Data"}
          </Inputs> */}
        </Container>
      );
    } else {
      return <Spinner />;
    }
  }
}

export default HomeScreen;
