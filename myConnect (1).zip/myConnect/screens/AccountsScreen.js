import React, { Component } from "react";
import {
  Button,
  ScrollView,
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  TextInput,
} from "react-native";

class AccountsScreen extends Component {
  state = {};
  render() {
    return (
      <View style={styles.container}>
        {/* <Text>Accounts Screen</Text> */}
        <FlatList
          data={[
            { key: "Name" },
            { key: "Phone Number" },
            { key: "Email" },
            { key: "Facebook" },
            { key: "LinkedIn" },
            { key: "Instagram" },
            { key: "Twitter" },
            { key: "Reddit" },
            { key: "TikTok" },
          ]}
          renderItem={({ item }) => (
            <TouchableOpacity>
              <Text style={styles.item}> {item.key} </Text>
              <TextInput
                style={{
                  margin: 15,
                  // width: window.width / 1.5,
                  // height: 40,
                  borderColor: "#7a42f4",
                  borderWidth: 1,
                  borderRadius: 10,
                  textAlign: "center",
                }}
                underlineColorAndroid="transparent"
                placeholder="Enter here"
                placeholderTextColor="#000"
                autoCapitalize="none"
                multiline={true}
              />
            </TouchableOpacity>
          )}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
  },
});

export default AccountsScreen;
