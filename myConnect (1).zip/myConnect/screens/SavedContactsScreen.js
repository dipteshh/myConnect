import React, { Component } from "react";
import { Button, StyleSheet, Text, View } from "react-native";

class SavedContactScreen extends Component {
  state = {};

  render() {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Text>Saved Contact Screen</Text>
      </View>
    );
  }
}

export default SavedContactScreen;
