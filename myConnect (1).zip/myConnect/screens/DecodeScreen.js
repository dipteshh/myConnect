// import React, { Component } from 'react';

// import { Container, TextH5 } from "../UI";

// // const {data} = this.route.params;
// class DecodeScreen extends Component {
//   state = {}
//   render() {
//     return (
//       <Container>
//         <TextH5>{"No"}</TextH5>
//       </Container>
//     );
//   }
// }

// export default DecodeScreen;

// // DecodeScreen.navigationOptions = {
// //   title: 'Decoded'
// // };
