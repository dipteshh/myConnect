import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyBmBTWpeQADTtiVuK7GaANXpyeDC7Lm3go",
  authDomain: "myconnect-db.firebaseapp.com",
  databaseURL:
    "https://myconnect-db-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "myconnect-db",
  storageBucket: "myconnect-db.appspot.com",
  messagingSenderId: "289993023405",
  appId: "1:289993023405:web:2caa75f3b9592ed1dd4b24",
};

firebase.initializeApp(firebaseConfig);
